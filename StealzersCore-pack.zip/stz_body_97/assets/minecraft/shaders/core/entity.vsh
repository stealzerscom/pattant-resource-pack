#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 core/entity.vsh plus the skinned player-display rig (adapted from bradleyq/stable_player_display, CC0).
// An item_display holding a player_head with item_model stealzers:body/<bone> is drawn 1024*k blocks below its
// bone; this shader moves it back and remaps the head cube's UVs onto the arm/torso/leg region of the same skin.
// Ordinary entities (k = 0) take the vanilla path unchanged.

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX) && !defined(OIT_ALPHA_ONLY)
#define STZ_PLAYERDISP 1
#endif

#ifdef VULKAN
#define STZ_VID gl_VertexIndex
#else
#define STZ_VID gl_VertexID
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

#ifdef STZ_PLAYERDISP
uniform sampler2D Sampler0;
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) out vec4 vertexPerFaceColorBack;
layout(location = 3) out vec4 vertexPerFaceColorFront;
#else
layout(location = 2) out vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) out vec4 overlayColor;
#endif

layout(location = 6) out vec2 texCoord0;
#ifdef GLINT
layout(location = 7) out vec2 texCoordGlint;
#endif

#ifdef STZ_PLAYERDISP
#define STZ_SPACING 1024.0
#define STZ_SKINRES 64
#define STZ_FACERES 8

const vec4 stzSubuvs[18] = vec4[](
    vec4(4.0, 0.0, 8.0, 4.0), vec4(8.0, 0.0, 12.0, 4.0), vec4(0.0, 4.0, 4.0, 16.0),
    vec4(4.0, 4.0, 8.0, 16.0), vec4(8.0, 4.0, 12.0, 16.0), vec4(12.0, 4.0, 16.0, 16.0),
    vec4(4.0, 0.0, 7.0, 4.0), vec4(7.0, 0.0, 10.0, 4.0), vec4(0.0, 4.0, 4.0, 16.0),
    vec4(4.0, 4.0, 7.0, 16.0), vec4(7.0, 4.0, 11.0, 16.0), vec4(11.0, 4.0, 14.0, 16.0),
    vec4(4.0, 0.0, 12.0, 4.0), vec4(12.0, 0.0, 20.0, 4.0), vec4(0.0, 4.0, 4.0, 16.0),
    vec4(4.0, 4.0, 12.0, 16.0), vec4(12.0, 4.0, 16.0, 16.0), vec4(16.0, 4.0, 24.0, 16.0));

const vec2 stzOrigins[10] = vec2[](
    vec2(40.0, 16.0), vec2(40.0, 32.0),   // right arm, sleeve
    vec2(32.0, 48.0), vec2(48.0, 48.0),   // left arm, sleeve
    vec2(16.0, 16.0), vec2(16.0, 32.0),   // torso, jacket
    vec2(0.0, 16.0), vec2(0.0, 32.0),     // right leg, pants
    vec2(16.0, 48.0), vec2(0.0, 48.0));   // left leg, pants

const int stzFaceRemap[8] = int[](0, 0, 1, 1, 2, 3, 4, 5);

bool stzRig(out vec3 wpos, out vec2 uv) {
    wpos = Position;
    uv = UV0;
    ivec2 dim = textureSize(Sampler0, 0);
    if (abs(ProjMat[2][3]) < 1e-5 || dim.x != STZ_SKINRES || dim.y != STZ_SKINRES || FogRenderDistanceEnd <= FogRenderDistanceStart) {
        return false;
    }
    int partId = -int(floor((Position.y + 0.5 * STZ_SPACING) / STZ_SPACING));
    if (partId < 1 || partId > 5) {
        return false;
    }
    int bone = partId - 1;
    vec4 s1 = texelFetch(Sampler0, ivec2(54, 20), 0);
    vec4 s2 = texelFetch(Sampler0, ivec2(55, 20), 0);
    bool slim = s1.a == 0.0 || ((s1.r + s1.g + s1.b) == 0.0 && (s2.r + s2.g + s2.b) == 0.0 && s1.a == 1.0 && s2.a == 1.0);
    int corner = STZ_VID % 4;
    int faceSlot = (STZ_VID % 24) / 4;
    ivec2 tile = ivec2(round(UV0 * float(STZ_SKINRES)));
    if ((faceSlot != 1 && corner >= 2) || (faceSlot == 1 && corner <= 1)) {
        tile.y -= STZ_FACERES;
    }
    if (corner == 0 || corner == 3) {
        tile.x -= STZ_FACERES;
    }
    tile /= STZ_FACERES;
    int outer = tile.x >= 4 ? 1 : 0;
    int face = stzFaceRemap[clamp((tile.x % 4) + 4 * tile.y, 0, 7)];
    int sub = face;
    if (slim && bone <= 1) {
        sub += 6;
    } else if (bone == 2) {
        sub += 12;
    }
    vec4 r = stzSubuvs[sub];
    vec2 off;
    if (face == 1) {
        off = corner == 0 ? r.zw : corner == 1 ? r.xw : corner == 2 ? r.xy : r.zy;
    } else {
        off = corner == 0 ? r.zy : corner == 1 ? r.xy : corner == 2 ? r.xw : r.zw;
    }
    uv = (stzOrigins[2 * bone + outer] + off) / float(STZ_SKINRES);
    wpos.y += STZ_SPACING * float(partId);
    return true;
}
#endif

void main() {
    vec3 pos = Position;
    texCoord0 = UV0;
#ifdef STZ_PLAYERDISP
    vec2 rigUv;
    if (stzRig(pos, rigUv)) {
        texCoord0 = rigUv;
    }
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

#ifdef GLINT
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
